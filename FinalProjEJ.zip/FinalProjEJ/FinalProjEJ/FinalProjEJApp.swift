//
//  FinalProjEJApp.swift
//  FinalProjEJ
//
//  Created by PM Student on 12/6/22.
//

import SwiftUI



@main
struct FinalProjEJApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
